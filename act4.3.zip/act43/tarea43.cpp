#include <iostream>
#include <string>
#include <set>
#include <vector>
#include <algorithm>

// =========================================================
// File: tarea43.cpp
// Author: Brisa Itzel Reyes Castro - A01710395
// Date: 10/11/2023
// =========================================================

using namespace std;

set<char> vertices;
set<pair<char, char>> edges;

bool dfs(char v, set<char>& visitados) {
    bool isTree = true;
    visitados.insert(v);

    // Recorrer las aristas
    for (auto e : edges) {
        // Si la arista tiene a v como vértice, hacer DFS
        if (e.first == v && visitados.count(e.second) == 0) {
            isTree &= dfs(e.second, visitados);
        }

        // Si la arista tiene a v como vértice, hacer DFS
        if (e.second == v && visitados.count(e.first) == 0) {
            isTree &= dfs(e.first, visitados);
        }
    }

    return isTree;
}

int main() {
    
    // Este programa cuenta la cantidad de árboles y acorns en un conjunto de aristas.

    

    // obtenemos la entrada 
    string linea;
    
    // Contador para aboles y acorns
    int arboles = 0;
    int acorns = 0;

    while (getline(cin, linea)) {
        if (linea[0] == '*') {
            break;
        }

        // Obtener vértices de las aristas
        char v1 = linea[1];
        char v2 = linea[3];
        edges.insert(make_pair(v1, v2));
    }

    getline(cin, linea);

    // Llenar el conjunto de vértices
    for (int i = 0; i < linea.size(); i++) {
        if (linea[i] != ',') {
            vertices.insert(linea[i]);
        }
    }

    // Imprimir los vértices
    for (char v : vertices) {
        cout << v << " ";
    }
    cout << endl;

    // Imprimir las aristas
    for (auto e : edges) {
        cout << "(" << e.first << "," << e.second << ") ";
    }
    cout << endl;

    // Hacer una lista con vértices que solo estén en aristas
    vector<char> verticesAristas;
    for (auto e : edges) {
        if (find(verticesAristas.begin(), verticesAristas.end(), e.first) == verticesAristas.end()) {
            verticesAristas.push_back(e.first);
        }
        if (find(verticesAristas.begin(), verticesAristas.end(), e.second) == verticesAristas.end()) {
            verticesAristas.push_back(e.second);
        }
    }

    // Contar la diferencia entre los vértices y los verticesAristas
    for (char v : vertices) {
        if (find(verticesAristas.begin(), verticesAristas.end(), v) == verticesAristas.end()) {
            acorns++;
        }
    }

    // Imprimir los vértices
    for (char v : verticesAristas) {
        cout << v << " ";
    }

    // Inicializar el conjunto de visitados y visitadosAnterior
    set<char> visitados;
    set<char> visitadosAnterior;

    // Recorrer los vértices
    for (char v : verticesAristas) {
        // Si no ha sido visitado, hacer DFS
        if (visitados.count(v) == 0) {

            // Si es un árbol, aumentar el contador
            if (dfs(v, visitados)) {
                arboles++;
            }

            // Imprimir los visitados
            for (char v : visitados) {
                cout << v << " ";
            }

            // Quitar los visitados de verticesAristas
            for (char v : visitados) {
                verticesAristas.erase(remove(verticesAristas.begin(), verticesAristas.end(), v), verticesAristas.end());
            }

            // Si visitados es el mismo que el visitadosAnterior, hacer un break
            if (visitados == visitadosAnterior) {
                arboles--;
                break;
            }

            cout << endl;
            visitadosAnterior = visitados;
            visitados.clear();
        }
    }

    // Imprimir el resultado
    cout << "There are " << arboles << " tree(s) and " << acorns << " acorn(s)." << endl;

    return 0;
}
