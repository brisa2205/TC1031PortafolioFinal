
// =========================================================
// File: flavio.cpp
// Author: Brisa Itzel Reyes - A01710395
// Date: 20/10/2023
// =========================================================

#include <iostream>
using namespace std;

class Node {
public:
    int value;      // Valor del nodo
    Node* next;     // Puntero al siguiente nodo
    Node* prev;     // Puntero al nodo anterior

    // Constructor de la clase Node
    Node(int val) : value(val), next(nullptr), prev(nullptr) {}
};

class CircularLinkedList {
private:
    Node* head;     // Puntero al primer nodo de la lista
    Node* tail;     // Puntero al último nodo de la lista
    int size;       // Tamaño de la lista
    int count;      // Contador para el sacrificio

public:
    // Constructor de la clase CircularLinkedList
    CircularLinkedList() : head(nullptr), size(0), count(0) {}

    // Obtener el nodo inicial (head) de la lista
    Node* getHead() {
        return head;
    }

    // Insertar un nuevo nodo con el valor 'val' en la lista
    void insert(int val) {
        Node* newNode = new Node(val);
        if (size == 0) {
            head = newNode;
            tail = newNode;
            head->next = tail;
            head->prev = tail;
            tail->next = head;
            tail->prev = head;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            newNode->next = head;
            head->prev = newNode;
            tail = newNode;
        }
        size++;
    }

    // Eliminar un nodo de la lista
    void deleteNode(Node* node) {
        if (size == 1) {
            head = nullptr;
            tail = nullptr;
        } else {
            if (node == head) {
                head = head->next;
                head->prev = tail;
                tail->next = head;
            } else if (node == tail) {
                tail = tail->prev;
                tail->next = head;
                head->prev = tail;
            } else {
                node->prev->next = node->next;
                node->next->prev = node->prev;
            }
        }
        node->next = nullptr;
        node->prev = nullptr;
        delete node;
        size--;
    }

    // Eliminar el 'k'-ésimo nodo a partir del nodo 'current'
    Node* eliminate(Node* current, int k) {
        for (int i = 1; i < k; i++) {
            current = current->next;
        }

        Node* victim = current->next;
        Node* replace = victim->next;

        if (victim == head) {
            head = replace;
        } else if (victim == tail) {
            tail = current;
        }

        deleteNode(victim);

        count++;

        return replace;
    }

    // Realizar un sacrificio recursivo hasta encontrar el nodo seguro
    Node* sacrifice(Node* current, int k) {
        if (size == 1) {
            return current;
        }

        count++;
        return sacrifice(eliminate(current, k), k + count);
    }

    // Obtener el tamaño de la lista
    int getSize() const {
        return size;
    }

    // Destructor de la clase CircularLinkedList
    ~CircularLinkedList() {
        while (size > 0) {
            Node* temp = head;
            head = head->next;
            delete temp;
            size--;
        }
    }
};

int main() {
    int n, k;
    cin >> n >> k;

    CircularLinkedList circle;

    for (int i = 1; i <= n; i++) {
        circle.insert(i);
    }
    Node* circleHead = circle.getHead();
    Node* safePosition = circle.sacrifice(circleHead, k);

    cout << endl << "Safe Position: " << safePosition->value << endl;

    return 0;
}
