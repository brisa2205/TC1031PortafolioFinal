// =========================================================
// Descripcion breve del programa:
// Este programa simula el juego de Josephus y encuentra la posicion segura.
// Autor: Brisa Itzel Reyes - A01710395
// Fecha de creacion/modificacion: 20/10/2023
// =========================================================

#include <iostream>
#include <list>

using namespace std;

// Funcion para encontrar la posicion segura en el juego de Josephus.

//  n: Numero total de personas en el circulo.
// survivor: Numero de personas a saltar antes de eliminar a una.

int findSafePosition(int n, int survivor) {
    if (survivor == 1) {
        return 1;
    } else {
        return n - survivor + 2;
    }
}

int main(int argc, char* argv[]) {
    // Entrada de datos
    int n, k;
    cin >> n >> k;

    // Inicializacion del circulo
    list<int> circle;
    for (int i = 1; i <= n; ++i) {
        circle.push_back(i);
    }

    // Iteradores para el circulo
    list<int>::iterator it = circle.begin();
    list<int>::iterator itK = it;

    // Simulacion del juego de Josephus
    while (circle.size() > 1) {
        // Avanzar k-1 veces para encontrar la posicion a eliminar
        for (int i = 0; i < k - 1; ++i) {
            ++it;
            if (it == circle.end()) {
                it = circle.begin();
            }
        }

        // Eliminar la posicion actual y ajustar el iterador
        it = circle.erase(it);
        if (it == circle.end()) {
            it = circle.begin();
        }

        // Guardar la posicion eliminada para reinsertarla despues
        itK = it;

        // Avanzar k-1 veces para encontrar la posicion siguiente a eliminar
        for (int j = 0; j < k - 1; ++j) {
            ++it;
            if (it == circle.end()) {
                it = circle.begin();
            }
        }

        // Reinsertar la posicion eliminada en la posicion correcta
        itK = circle.emplace(itK, *it);
        circle.erase(it);
        it = itK;
        ++it;
    }

    // Encontrar y mostrar la posicion segura
    int safePos = findSafePosition(n, circle.front());
    cout << safePos << endl;

    return 0;
}
