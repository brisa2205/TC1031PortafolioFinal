// ######################################################################################################################
// # Actividad Integradora 52: Tablas de Hash 
// # Descripción de la actividad: Implementar una tabla de hash para resolver el problema de la actividad integradora 51.
// # Fecha: 10 de Noviembre del 2020
// # Autor: Brisa Reyes Castro | A01710395
// ######################################################################################################################


// Librearias utilizadas
#include <iostream>     // Libreria para entradaa y salida
#include <vector>       // Libreria para utilizar vectores
#include <map>          // Libreria para utilizar mapas
#include <set>          // Libreria para utilizar sets
#include <sstream>      // Libreria para utilizar istringstream
#include <algorithm>    // Libreria para utilizar sort

using namespace std;

// Implementación de la estructura Concursante
struct concursante{
    int equipo;
    int problemas;
    int tiempo;
    map<int, int> intentos_incorrectos;
    set<int> problemas_resueltos_set;
    // Inicialización de los valores de la estructura
    concursante(){
        equipo=0;
        problemas=0;
        tiempo=0;
    }

};

// Inicialización de la función main para calcular los resultados de los concursantes
int main(){
    vector<concursante> concursantes(105); // Inicialización del vector de concursantes con 105 vcetores
    string line;   // Inicialización de la variable line como string

    // Recibe equipo y los datos para calcular sus resultados
    while (getline(cin, line)) {    // Complejidad O(n)
        istringstream ss(line);     // Inicialización de la variable ss como istringstream
        int equipo, problema, tiempo;   // Inicialización de las variables equipo, problema y tiempo como int
        char resultado;     // Inicialización de la variable resultado como char
        ss >> equipo >> problema >> tiempo >> resultado;    // Asignación de los valores de las variables

        concursantes[equipo].equipo = equipo;    // Asignación del valor de equipo a la variable equipo de la estructura concursante
        if (resultado == 'C' || resultado == 'I') {   // Condicional para verificar si el resultado es C o I
            if (resultado == 'C' && concursantes[equipo].problemas_resueltos_set.find(problema) == concursantes[equipo].problemas_resueltos_set.end()) {    // Condicional para verificar si el resultado es C y si el problema ya fue resuelto
                concursantes[equipo].problemas++;   // Aumenta el número de problemas resueltos
                concursantes[equipo].tiempo += tiempo + (20 * concursantes[equipo].intentos_incorrectos[problema]);    // Aumenta el tiempo penalizado
                concursantes[equipo].problemas_resueltos_set.insert(problema);   // Inserta el problema resuelto al set de problemas resueltos
            } else if (resultado == 'I') {  // Condicional para verificar si el resultado es I
                concursantes[equipo].intentos_incorrectos[problema]++;   // Aumenta el número de intentos incorrectos
            }
        }
    }





vector<concursante> concursantes_validos;    // Inicialización del vector de concursantes validos

for  (int i = 1; i < 105; i++) {
    if (concursantes[i].problemas > 0 || concursantes[i].tiempo > 0) {
        concursantes_validos.push_back(concursantes[i]);
    }
}

//imprimir la salida 
for (int i = 1; i < 101; i++) {
        if (concursantes[i].equipo == i && concursantes[i].problemas == 0 && concursantes[i].tiempo == 0) {
            concursantes_validos.push_back(concursantes[i]);
        }
    }

           
//ordenar los concursantes


sort(concursantes_validos.begin(), concursantes_validos.end(),
[](const concursante& otro, const concursante& otro_b){
        if(otro.problemas==otro_b.problemas){
            if(otro.tiempo==otro_b.tiempo){
                return otro.equipo<otro_b.equipo;
            }
            return otro.tiempo<otro_b.tiempo;
        }
        return otro.problemas>otro_b.problemas;

    }
);
 
 //imprimir la salida 
for  (const concursante& concursante : concursantes_validos) {
            cout << concursante.equipo << " " << concursante.problemas << " " << concursante.tiempo << endl;
        }
        return 0;
}