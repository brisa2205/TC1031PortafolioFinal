// Descripcion breve del programa:
// Este programa verifica si un arbol cumple con ciertas condiciones.
// Autor: [Brisa Itzel Reyes Castro] - A01710395
// Fecha de creacion/modificacion: [03/11/2023]

#include <bits/stdc++.h>
using namespace std;

vector<int> arbol[2000];
bool visitado[2000];

// Funcion que verifica si el arbol cumple con las condiciones.
// Parametros:
// - node: El nodo actual en el recorrido del arbol.
// Retorna: true si el arbol cumple con las condiciones, false en caso contrario.
bool dfs(int node) {
    visitado[node] = true;
// Marcamos el nodo actual como visitado.
// Inicializamos un contador para contar los hijos hoja del nodo actual.
    int hijohoja= 0;
// Recorremos los hijos del nodo actual.
    for (int hijo : arbol[node]) {
        // Verificamos si el hijo es un nodo hoja (tiene solo un hijo).
        if (!visitado[hijo]) {
            if (arbol[hijo].size() == 1) {
                hijohoja++;
            } else if (!dfs(hijo)) {
                return false;
            }
        }
    }
    return hijohoja >= 3 || arbol[node].size() == 1;
}

int main() {
    //leemos canridad de nodos en el arbol
    int n;
    cin >> n;
//hacemos las relaciones
    for (int i = 2; i <= n; i++) {
        int padre;

//leemos nodo padre
        cin >> padre;
 // Establecemos las conexiones bidireccionales entre el nodo padre y el nodo actual.
        arbol[padre].push_back(i);
        arbol[i].push_back(padre);
    }

    if (dfs(1)) {
        cout << "Yes";
    } else {
        cout << "No";
    }

    return 0;
}

